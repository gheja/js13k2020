type tPoint3D = tVec3;

// A list of goods. Array key is the GOOD_*, value is the current value or whether acceptable (0/1).
type tGoodList = Array<number>;
